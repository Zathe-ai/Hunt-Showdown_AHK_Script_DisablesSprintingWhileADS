Created by ZATHE
Disables Sprint while in ADS to prevent aim interruption in Hunt Showdown



Application.exe is only for if u don't want to install AHK, otherwise just double click the Script each time to use. 
You can right click the Script and edit in notepad to view the code.

**Some games anti-cheat wont allow AHK, so you might want to setup the AHK to only open with Hunt Showdown** otherwise u have to close it when playing other games


*you have to manually open the script each time you play unless you put the exe. in your /Win Startup/ folder

	to do this simply:

	1. right-click the Application exe. --> show more options --> create shortcut 

	2. then drag the shortcut into your startup folder, located: "%appdata%\Microsoft\Windows\Start Menu\Programs\Startup"	
	3. enjoy hunters